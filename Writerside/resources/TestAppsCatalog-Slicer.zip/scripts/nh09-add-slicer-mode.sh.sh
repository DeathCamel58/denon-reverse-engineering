#!/bin/sh

# Remount the root filesystem to allow modifications
mount -o remount rw /

# Add slicer to the controller mapping
# The slicer will be available on SHIFT + AUTO LOOP
sed -i "s/view: 'AUTO'/view: 'AUTO'\n\t\t\t\t\t\tshiftView: 'SLICER'/" /usr/Engine/AssignmentFiles/PresetAssignmentFiles/NH09/NH09_Controller_Assignments.qml

# Restart the Engine Service
systemctl restart engine

