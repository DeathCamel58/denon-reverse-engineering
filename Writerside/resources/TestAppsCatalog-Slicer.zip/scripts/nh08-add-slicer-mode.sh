#!/bin/sh

# Remount the root filesystem to allow modifications
mount -o remount rw /

# Add slicer to the controller mapping
# The slicer will be available on SHIFT + LOOP
sed -i "s/view: 'LOOPS'/view: 'LOOPS'\n\t\t\t\t\t\tshiftView: 'SLICER'/" /usr/Engine/AssignmentFiles/PresetAssignmentFiles/NH08/NH08_Controller_Assignments.qml

# Restart the Engine Service
systemctl restart engine

